#!/bin/sh

while true
do
    /home/pi/can-test_pi2/cansend can0 18EAFF80#70FE000000000000
    sleep 1
done

