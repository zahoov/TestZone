#!/bin/sh

# * * * * * sh /home/pi/Desktop/logger-rbp-python/requestCANID-unixExtract-crontab.sh

while true
do
    /home/pi/Desktop/can-test_pi2/cansend can0 18EAFF80#70FE00
    /home/pi/Desktop/can-test_pi2/cansend can0 18EAFF80#49FC00
    /home/pi/Desktop/can-test_pi2/cansend can0 18EAFF80#A0FC00
    /home/pi/Desktop/can-test_pi2/cansend can0 18EAFF80#48FC00
    /home/pi/Desktop/can-test_pi2/cansend can0 18EAFF80#79FD00
    /home/pi/Desktop/can-test_pi2/cansend can0 18EAFF80#78FD00
    /home/pi/Desktop/can-test_pi2/cansend can0 18EAFF80#98FD00
    /home/pi/Desktop/can-test_pi2/cansend can0 18EAFF80#99FD00
    /home/pi/Desktop/can-test_pi2/cansend can0 18EAFF80#E8FB00
    /home/pi/Desktop/can-test_pi2/cansend can0 18EAFF80#E6FE00
    /home/pi/Desktop/can-test_pi2/cansend can0 18EAFF80#CFFE00

    sleep 1
done


